# T6ServerConfigs
This repo contains the T6 Dedicated Server Config for PlutoniumT6

Tutorials on how to use them can be found on:
* [AWOG Community Forum](https://forum.awog.at/topic/32/)
* [Plutonium Forum](https://forum.plutonium.pw/topic/13)
* [REACTion Gaming Forum](https://reactiongaming.us/community/threads/how-to-setup-your-dedicated-server-for-plutot6.1358/)
