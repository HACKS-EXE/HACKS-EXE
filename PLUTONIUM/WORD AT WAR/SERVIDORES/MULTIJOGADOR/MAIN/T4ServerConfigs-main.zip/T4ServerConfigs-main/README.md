# T4 Server Configs
This repo contains the T4 Dedicated Server Config for Plutonium T4.

Tutorials on how to use them can be found on:
* [Plutonium Forum](https://forum.plutonium.pw/topic/6976/)